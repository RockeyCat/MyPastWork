#!/usr/bin/bash

cloudwatch_group_name=${cloudwatch_group_name}

sudo yum update -y
sudo su
echo "Installing Java 11.."
amazon-linux-extras install java-openjdk11 -y
echo "Setting openjdk11 as default.."
sudo /usr/sbin/alternatives --set java /usr/lib/jvm/java-11-openjdk-11.0.2.7-0.amzn2.x86_64/bin/java
sudo /usr/sbin/alternatives --set javac /usr/lib/jvm/java-11-openjdk-11.0.2.7-0.amzn2.x86_64/bin/javac

## Verifying Tomcat Installation Directory ##
sudo cd /usr/share
mkdir tomcat 
sudo amazon-linux-extras install tomcat8.5 -y
sudo systemctl enable tomcat
sudo systemctl start tomcat
sudo cd /usr/share/tomcat/webapps/
sudo wget https://tomcat.apache.org/tomcat-7.0-doc/appdev/sample/sample.war

#Enable Cloudwatch
sudo yum update -y
sudo yum install awslogs -y
sudo sed -i "s/log_group_name = \/var\/log\/messages/log_group_name = ${cloudwatch_group_name}/" /etc/awslogs/awslogs.conf
sudo sed -i 's/us-east-1/us-east-1/g' /etc/awslogs/awscli.conf
sudo service awslogsd start
sudo systemctl  enable awslogsd

#PostgressClient 

sudo amazon-linux-extras install postgresql10
#Codedeploy install
sudo yum install ruby -y
sudo yum install wget -y
sudo cd /home/ec2-user
sudo wget https://aws-codedeploy-us-east-1.s3.us-east-1.amazonaws.com/latest/install
sudo chmod +x ./install
sudo ./install auto
sudo service codedeploy-agent status
sudo service codedeploy-agent start
sudo service codedeploy-agent status

#Installing One Agent

sudo wget  -O Dynatrace-OneAgent-Linux-1.263.138.sh "https://ced58187.live.dynatrace.com/api/v1/deployment/installer/agent/unix/default/latest?arch=x86&flavor=default&networkZone=shared_services_prod" --header="Authorization: Api-Token dt0c01.RSHHDTKCRU2SPGGIEY2PJDOI.HIFII2IR6ASJXFPP6MSY5Z5Q6EKUFF2H2E4DKNWMM3FWHBBUNP6WBRGX5WH5SESK"
sudo wget https://ca.dynatrace.com/dt-root.cert.pem ; ( echo 'Content-Type: multipart/signed; protocol="application/x-pkcs7-signature"; micalg="sha-256"; boundary="--SIGNED-INSTALLER"'; echo ; echo ; echo '----SIGNED-INSTALLER' ; cat Dynatrace-OneAgent-Linux-1.263.138.sh ) | openssl cms -verify -CAfile dt-root.cert.pem > /dev/null
sudo /bin/sh Dynatrace-OneAgent-Linux-1.263.138.sh --set-infra-only=false --set-app-log-content-access=true --set-network-zone=shared_services_prod --set-host-group=GRP-Argus-PROD

sudo tee -a /var/lib/dynatrace/oneagent/agent/config/logmodule/script.json <<EOF{
    "@version":"1.0.0",
    "allowed-log-paths-configuration":[
       {
          "directory-pattern":"/usr/share/tomcat/AppLog/*-*-*/*.log",
          "file-pattern":"*",
          "action":"INCLUDE"
       }
    ]
 }

EOF

sudo service oneagent stop
sudo service oneagent start

